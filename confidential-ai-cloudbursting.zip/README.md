# Confidential AI Cloud-Bursting Inferencing

This repository contains Terraform and Kubernetes manifests for deploying a confidential AI inferencing system with cloud-bursting capabilities.

## Structure

- `terraform/`: Provision confidential VMs and GPU burst nodes across cloud providers.
- `kubernetes/`: Deploy secure inference pods and autoscaling with KEDA.

## Usage

1. Configure your cloud provider credentials.
2. Apply Terraform scripts to provision infrastructure.
3. Deploy Kubernetes manifests to your cluster.