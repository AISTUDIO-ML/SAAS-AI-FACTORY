import React, { useState, useEffect } from 'react';
import axios from 'axios';

const MetaAdsCampaignWizard: React.FC = () => {
  const [form, setForm] = useState({
    name: '',
    age_min: 18,
    age_max: 34,
    interests: ['health', 'fitness'],
    countries: ['US'],
    daily_budget: 1000,
    campaign_id: ''
  });

  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<any>(null);
  const [analytics, setAnalytics] = useState<any>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const res = await axios.post('https://your-api-url/create_campaign', {
        ...form,
        interests: form.interests.map(i => i.trim()),
        countries: form.countries.map(c => c.trim())
      });
      setResponse(res.data);
      fetchAnalytics(form.campaign_id);
    } catch (error) {
      console.error(error);
      alert('Failed to create campaign');
    } finally {
      setLoading(false);
    }
  };

  const fetchAnalytics = async (campaignId: string) => {
    try {
      const res = await axios.get(`https://your-api-url/campaign_insights?campaign_id=${campaignId}`);
      setAnalytics(res.data);
    } catch (error) {
      console.error('Analytics fetch failed', error);
    }
  };

  return (
    <div className="max-w-xl mx-auto p-6 bg-white shadow-md rounded-md">
      <h2 className="text-2xl font-bold mb-4">🎯 Launch Meta Ads Campaign</h2>

      <div className="space-y-4">
        <input
          type="text"
          name="name"
          placeholder="Campaign Name"
          value={form.name}
          onChange={handleChange}
          className="w-full p-2 border rounded"
        />

        <input
          type="text"
          name="campaign_id"
          placeholder="Meta Campaign ID"
          value={form.campaign_id}
          onChange={handleChange}
          className="w-full p-2 border rounded"
        />

        <div className="flex space-x-2">
          <input
            type="number"
            name="age_min"
            placeholder="Min Age"
            value={form.age_min}
            onChange={handleChange}
            className="w-1/2 p-2 border rounded"
          />
          <input
            type="number"
            name="age_max"
            placeholder="Max Age"
            value={form.age_max}
            onChange={handleChange}
            className="w-1/2 p-2 border rounded"
          />
        </div>

        <input
          type="text"
          name="interests"
          placeholder="Interests (comma separated)"
          value={form.interests.join(', ')}
          onChange={(e) => setForm({ ...form, interests: e.target.value.split(',') })}
          className="w-full p-2 border rounded"
        />

        <input
          type="text"
          name="countries"
          placeholder="Countries (comma separated)"
          value={form.countries.join(', ')}
          onChange={(e) => setForm({ ...form, countries: e.target.value.split(',') })}
          className="w-full p-2 border rounded"
        />

        <input
          type="number"
          name="daily_budget"
          placeholder="Daily Budget (in cents)"
          value={form.daily_budget}
          onChange={handleChange}
          className="w-full p-2 border rounded"
        />

        <button
          onClick={handleSubmit}
          disabled={loading}
          className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
        >
          {loading ? 'Launching...' : 'Launch Campaign'}
        </button>

        {response && (
          <div className="mt-4 p-4 bg-green-100 border border-green-400 rounded">
            <h3 className="font-bold">✅ Campaign Created</h3>
            <pre className="text-sm">{JSON.stringify(response, null, 2)}</pre>
          </div>
        )}

        {analytics && (
          <div className="mt-6 p-4 bg-gray-100 border border-gray-300 rounded">
            <h3 className="text-lg font-semibold mb-2">📊 Campaign Analytics</h3>
            <ul className="text-sm space-y-1">
              <li><strong>Impressions:</strong> {analytics.impressions}</li>
              <li><strong>Reach:</strong> {analytics.reach}</li>
              <li><strong>Spend:</strong> ${parseFloat(analytics.spend).toFixed(2)}</li>
              <li><strong>Clicks:</strong> {analytics.clicks}</li>
              <li><strong>CTR:</strong> {analytics.ctr}%</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default MetaAdsCampaignWizard;