import requests
from config import META_ACCESS_TOKEN, META_AD_ACCOUNT_ID

def fetch_interest_ids(keywords):
    ids = []
    for keyword in keywords:
        response = requests.get(
            f"https://graph.facebook.com/v18.0/search",
            params={
                "type": "adinterest",
                "q": keyword,
                "access_token": META_ACCESS_TOKEN
            }
        )
        data = response.json().get("data", [])
        if data:
            ids.append({"id": data[0]["id"], "name": data[0]["name"]})
    return ids

def create_ad_set(payload):
    url = f"https://graph.facebook.com/v18.0/{META_AD_ACCOUNT_ID}/adsets"
    response = requests.post(url, data=payload)
    return response.json()

def get_campaign_insights(campaign_id):
    url = f"https://graph.facebook.com/v18.0/{campaign_id}/insights"
    params = {
        "fields": "impressions,reach,spend,clicks,ctr",
        "access_token": META_ACCESS_TOKEN
    }
    response = requests.get(url, params=params)
    return response.json()["data"][0] if response.ok and response.json().get("data") else {}