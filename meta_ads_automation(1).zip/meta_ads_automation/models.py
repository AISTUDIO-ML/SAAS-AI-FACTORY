from pydantic import BaseModel
from typing import List

class CampaignRequest(BaseModel):
    name: str
    age_min: int
    age_max: int
    interests: List[str]
    countries: List[str]
    daily_budget: int
    campaign_id: str