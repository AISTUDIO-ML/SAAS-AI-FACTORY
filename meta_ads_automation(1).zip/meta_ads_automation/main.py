from fastapi import FastAPI
from models import CampaignRequest
from meta_ads import fetch_interest_ids, create_ad_set, get_campaign_insights

app = FastAPI()

@app.post("/create_campaign")
def create_campaign(request: CampaignRequest):
    interests = fetch_interest_ids(request.interests)
    targeting = {
        "age_min": request.age_min,
        "age_max": request.age_max,
        "geo_locations": {"countries": request.countries},
        "interests": interests
    }

    payload = {
        "name": request.name,
        "daily_budget": request.daily_budget,
        "billing_event": "IMPRESSIONS",
        "optimization_goal": "REACH",
        "campaign_id": request.campaign_id,
        "targeting": targeting,
        "status": "PAUSED",
        "access_token": META_ACCESS_TOKEN
    }

    result = create_ad_set(payload)
    return result

@app.get("/campaign_insights")
def campaign_insights(campaign_id: str):
    return get_campaign_insights(campaign_id)