// IndexedDB setup
let db;
const request = indexedDB.open('AnalyticsDB', 1);

request.onupgradeneeded = function(event) {
  db = event.target.result;
  db.createObjectStore('events', { autoIncrement: true });
};

request.onsuccess = function(event) {
  db = event.target.result;
  window.addEventListener('online', syncEvents);
};

function trackEvent(eventName) {
  const transaction = db.transaction(['events'], 'readwrite');
  const store = transaction.objectStore('events');
  store.add({ event: eventName, timestamp: Date.now() });
}

function syncEvents() {
  const transaction = db.transaction(['events'], 'readonly');
  const store = transaction.objectStore('events');
  const getAll = store.getAll();

  getAll.onsuccess = function() {
    const events = getAll.result;
    if (events.length > 0) {
      console.log('Syncing events:', events);
      // Simulate sending to server
      const tx = db.transaction(['events'], 'readwrite');
      const clearStore = tx.objectStore('events');
      clearStore.clear();
    }
  };
}
